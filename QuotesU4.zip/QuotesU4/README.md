# QuotesApp-WebServices

Este proyecto esta pensado para fines academicos
y se irá agregando nuevas caracteristicas 
conforme se avance en el curso

